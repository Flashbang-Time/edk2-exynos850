#ifndef _PLATFORM_PREPI_LIB_H_
#define _PLATFORM_PREPI_LIB_H_

VOID PlatformInitialize();

#endif /* _PLATFORM_UTILS_H_ */