#ifndef _PLATFORM_UTILS_H_
#define _PLATFORM_UTILS_H_

#include <Library/PcdLib.h>

VOID PlatformInitialize();

#endif /* _PLATFORM_UTILS_H_ */