### Prerequisites

* [ ] Have you read the wiki?
* [ ] Is your device in the supported list?
* [ ] Does the device have a Snapdragon SOC which is supported in this repo?

### Description

[Description of the bug or feature]

**Expected behavior:** [What you expected to happen]

**Actual behavior:** [What actually happened]
