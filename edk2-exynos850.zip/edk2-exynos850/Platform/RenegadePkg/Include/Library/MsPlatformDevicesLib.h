#ifndef __MS_PLATFORM_H
#define __MS_PLATFORM_H

VOID
EFIAPI
PlatformSetup();

#endif