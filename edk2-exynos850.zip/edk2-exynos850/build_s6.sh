#!/bin/bash

GCC5_AARCH64_PREFIX=aarch64-linux-gnu- ./build.sh -d s6 -t GCC5 -r DEBUG
